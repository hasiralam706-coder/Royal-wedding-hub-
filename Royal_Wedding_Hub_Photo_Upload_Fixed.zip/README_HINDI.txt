ROYAL WEDDING HUB — ANDROID PROJECT

This project wraps the supplied website in an Android WebView app.
The app icon was kept from the supplied app-icon.png and used for Android launcher icon.
The supplied header-logo.png remains the website header logo.

BUILD APK USING GITHUB ACTIONS (mobile-friendly):
1. Upload the CONTENTS of this ZIP to the root of a GitHub repository (not the ZIP file itself).
2. Keep .github/workflows/build.yml in the repository.
3. Open Actions -> Build Royal Wedding Hub APK -> Run workflow.
4. When complete, open the run and download the "Royal-Wedding-Hub-APK" artifact.
5. Extract the downloaded artifact ZIP to get app-debug.apk.

Important:
- This is an Android Studio Gradle project, not a prebuilt APK.
- It uses Gradle 8.9 through GitHub Actions; a local gradlew wrapper is not required for the provided workflow.
- Website photo uploads depend on the existing website's browser/cloud upload configuration.
